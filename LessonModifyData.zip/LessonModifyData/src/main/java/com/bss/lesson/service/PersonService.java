package com.bss.lesson.service;

import com.bss.lesson.domain.Person;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PersonService {

    private Map<Integer,Person> map = new HashMap();
    private int totalNumber = 0;

    public PersonService() {

        for (; totalNumber < 10; totalNumber++) {
            Person p = new Person();

            p.setId(totalNumber);
            p.setName("bss_" + totalNumber);
            p.setAge(10 + totalNumber);

            map.put(totalNumber, p);
        }
    }

    public Person getPerson(int id){

        return map.get(id);
    }

    public void insert(String name, int age){
        Person p = new Person();
        p.setId(totalNumber);
        p.setName(name);
        p.setAge(age);

        map.put(totalNumber, p);
        totalNumber++;

    }

    public void modifyData(int Number, String name, int age){

        Person p = new Person();

        p.setId(Number);
        p.setName(name);
        p.setAge(age);

        map.put(Number, p);
    }

    public List<Person> findAll(){

        return new ArrayList(map.values());
    }
}
