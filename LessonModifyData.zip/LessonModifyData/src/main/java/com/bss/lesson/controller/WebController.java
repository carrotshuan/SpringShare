package com.bss.lesson.controller;

import com.bss.lesson.domain.Person;
import com.bss.lesson.service.PersonService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Controller
public class WebController {

    @Resource
    PersonService ps;


    @RequestMapping(value = "/index")
    public String goCeshi(){

        return "index";
    }

    @RequestMapping("/show")
    public String findAllData(Map<String,Object> model){

        List<Person> personList = ps.findAll();
        model.put("personList",personList);
        return "dataShow";
    }

    @RequestMapping("/insert")
    public String insertData(){

        return "insertPage";
    }

    @RequestMapping("/doInsert")
    public String doInsert(HttpServletRequest httpServletRequest, Map<String, Object> model){

        String name = httpServletRequest.getParameter("name");
        String age = httpServletRequest.getParameter("age");
        System.out.println("Name:"+name+"\nAge:"+age);

        int ageNum = 0;
        try {
            ageNum = Integer.parseInt(age);
        }
        catch (Exception e){}

        ps.insert(name,ageNum);
        List<Person> personList = ps.findAll();
        model.put("personList", personList);

        return "redirect:/show";
    }

    @RequestMapping("/modify")
    public String modify(@RequestParam Integer id, Model model){

        System.out.println(id);
        Person person = ps.getPerson(id);

        model.addAttribute("modifyPerson", person);

        return "modify";
    }

}
