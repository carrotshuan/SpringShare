package com.bss.lesson.service;

import com.bss.lesson.domain.Person;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PersonService {

    private static Map<Integer,Person> map = new HashMap<Integer, Person>();

    static {
        for (int i = 0;i<10;i++){
            Person p = new Person();

            p.setId(i);
            p.setName("bss"+i);
            p.setAge(10+i);

            map.put(i,p);
        }
    }

    public List<Person> findAll(){

        return new ArrayList(map.values());
    }
}
