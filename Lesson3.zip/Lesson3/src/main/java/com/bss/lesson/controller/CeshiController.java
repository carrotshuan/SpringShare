package com.bss.lesson.controller;

import com.bss.lesson.domain.Person;
import com.bss.lesson.service.PersonService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Controller
public class CeshiController {

    @Resource
    PersonService ps;


    @RequestMapping(value = "/ceshi")
    public String goCeshi(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse){

        System.out.println(httpServletRequest.getRequestURL());

        return "index";
    }

    @RequestMapping("/person/all")
    public String findAllData(Map<String,Object> model){

        List<Person> personList = ps.findAll();
        model.put("personList",personList);
        return "jPersonList";
    }
}
